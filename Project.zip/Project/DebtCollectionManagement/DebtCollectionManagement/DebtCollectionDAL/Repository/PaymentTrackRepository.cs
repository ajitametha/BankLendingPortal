﻿using DebtCollectionDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DebtCollectionDAL;
using Microsoft.EntityFrameworkCore;

namespace DebtCollectionDAL.Repository
{
    public class PaymentTrackRepository:IPaymentTrackRepository
    {
        private readonly DebtCollectionContext _context;

        public PaymentTrackRepository(DebtCollectionContext context)
        {
            _context = context;
        }

        public void AddPaymentTrack(PaymentTrack paymentTrack)
        {
            _context.PaymentTracks.Add(paymentTrack);
            _context.SaveChanges();
        }

        public void UpdatePaymentStatus(PaymentTrack model,string PaymentTrackid)
        {
            var paymentTrack = _context.PaymentTracks.Find(PaymentTrackid);

            if(paymentTrack != null)
            {
                paymentTrack.Status = model.Status;
                _context.Entry(paymentTrack).State=EntityState.Modified;
                _context.SaveChanges();
            }
        }

        public List<PaymentTrack> GetDefaultersbydate()
        { 
           var temp=_context.PaymentTracks.Where(p => p.Status == "Not Received" ).ToList();
            return temp;
        }
        public List<PaymentTrack> GetList()
        {
            var temp = _context.PaymentTracks.ToList();
            return temp;
        }

    }
}
