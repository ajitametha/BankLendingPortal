﻿using DebtCollectionDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebtCollectionDAL.Repository
{
    public interface IPaymentTrackRepository
    {
        public void AddPaymentTrack(PaymentTrack paymentTrack) { }
        public void UpdatePaymentStatus(PaymentTrack model,string PaymentTrackid) { }
        public List<PaymentTrack> GetDefaultersbydate() { return null; }
        public List<PaymentTrack> GetList() { return null; }
    }
}

