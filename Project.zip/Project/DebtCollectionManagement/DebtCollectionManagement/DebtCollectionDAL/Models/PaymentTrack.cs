﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebtCollectionDAL.Models
{
    public class PaymentTrack
    {
        [Key]
        [Required]
        public string PaymentTrackId { get; set; }
        [Required]

        public string LoanAppId { get; set; }
        [Required]

        public int MonthNo { get; set; }
        [Required]

        [RegularExpression("Received|Not Received")]

        public string Status { get; set; } = "Not Received";
        [Required]

        [DataType(DataType.Date)]

        public DateTime DueDateOfPayment { get; set; }
        [Required]

        [DataType(DataType.Date)]
        public DateTime PaymentReceiveDate { get; set; }
    }
}
