﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DebtCollectionDAL.Models;
using Microsoft.EntityFrameworkCore;

namespace DebtCollectionDAL
{
    public class DebtCollectionContext: DbContext

    {
        public DebtCollectionContext(DbContextOptions<DebtCollectionContext> options): base(options)
        {
            
        }
        public DbSet<PaymentTrack> PaymentTracks { get; set; }

        //tb

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=LTIN261703; Initial Catalog=DebtCollectionManagement ;Integrated Security=SSPI; TrustServerCertificate=True");
            base.OnConfiguring(optionsBuilder); 
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PaymentTrack>()
                .Property(s=>s.DueDateOfPayment)
                .HasColumnType("date");

            modelBuilder.Entity<PaymentTrack>()
                .Property(s => s.PaymentReceiveDate)
                .HasColumnType("date");

            modelBuilder.Entity<PaymentTrack>()
                .Property(s => s.Status)
                .HasDefaultValue("Not Received");
        }
    }
}
