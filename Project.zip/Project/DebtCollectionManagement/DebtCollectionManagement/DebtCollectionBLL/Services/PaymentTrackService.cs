﻿using AutoMapper;
using DebtCollectionBLL.DTOs;
using DebtCollectionDAL.Models;
using DebtCollectionDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebtCollectionBLL.Services
{
    public class PaymentTrackService:IPaymentTrackService
    {
        private readonly IPaymentTrackRepository _repository;
        private readonly IMapper _mapper;

        public PaymentTrackService(IPaymentTrackRepository repository,
            IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }


       public void AddPaymentTrack(PaymentTrackDTO paymentTrack)
        {
            var track = new PaymentTrack
            {
                PaymentTrackId = paymentTrack.PaymentTrackId,
                LoanAppId = paymentTrack.LoanAppId,
                MonthNo = paymentTrack.MonthNo,
                Status = paymentTrack.Status,
                DueDateOfPayment = paymentTrack.DueDateOfPayment,
                PaymentReceiveDate = paymentTrack.PaymentReceiveDate
            };
            _repository.AddPaymentTrack(track);
        }

        public void UpdatePaymentStatus(UpdateTrackDTO model,string PaymentTrackid)
        {
            if (model.Status != "Received" && model.Status != "Not Received")
                throw new ArgumentException("Invalid status");
            var track = new PaymentTrack
            {
               Status = model.Status
            };
            _repository.UpdatePaymentStatus(track,PaymentTrackid);
        }

        public List<PaymentTrackDTO> GetDefaultersbydate15()
        {
            List<PaymentTrack> defaulters=(List<PaymentTrack>)_repository.GetDefaultersbydate();
            List<PaymentTrackDTO> result = new List<PaymentTrackDTO>();
            foreach(PaymentTrack defaulter in defaulters)
            {
                PaymentTrackDTO value=_mapper.Map<PaymentTrackDTO>(defaulter);
                result.Add(value);
            }
            return result.Where(p => p.PaymentReceiveDate.Day > 15).ToList();
        }


        public List<PaymentTrackDTO> GetDefaulterstrackforpayment()
        {
            List<PaymentTrack> defaulters = 
                (List<PaymentTrack>)_repository.GetDefaultersbydate();
            List<PaymentTrackDTO> result = new List<PaymentTrackDTO>();
            foreach (PaymentTrack defaulter in defaulters)
            {
                PaymentTrackDTO value = _mapper.Map<PaymentTrackDTO>(defaulter);
                result.Add(value);
            }
            return result;
        }
        public List<PaymentTrackDTO> GetListOfRecord()
        {
            List<PaymentTrack> defaulters = 
                (List<PaymentTrack>)_repository.GetList();
            List<PaymentTrackDTO> result = new List<PaymentTrackDTO>();
            foreach (PaymentTrack defaulter in defaulters)
            {
                PaymentTrackDTO value = _mapper.Map<PaymentTrackDTO>(defaulter);
                result.Add(value);
            }
            return result;
        }



    }
}
