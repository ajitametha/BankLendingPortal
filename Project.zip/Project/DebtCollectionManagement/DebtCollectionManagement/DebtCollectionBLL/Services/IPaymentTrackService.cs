﻿using DebtCollectionBLL.DTOs;
using DebtCollectionDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebtCollectionBLL.Services
{
    public interface IPaymentTrackService
    {

        public void AddPaymentTrack(PaymentTrackDTO paymentTrack) { }
        public void UpdatePaymentStatus(UpdateTrackDTO model,string PaymentTrackid) { }
        public List<PaymentTrackDTO> GetDefaultersbydate15() { return null; }
        public List<PaymentTrackDTO> GetDefaulterstrackforpayment() { return null; }
        public List<PaymentTrackDTO> GetListOfRecord() { return null; }
    }
}
