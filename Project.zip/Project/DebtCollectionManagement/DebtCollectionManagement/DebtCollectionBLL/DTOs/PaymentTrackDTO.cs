﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebtCollectionBLL.DTOs
{
    public class PaymentTrackDTO
    {
        public string PaymentTrackId { get; set; }
        public string LoanAppId { get; set; }
        
        public int MonthNo { get; set; }
       
        public string Status { get; set; } = "Not Received";
        
        public DateTime DueDateOfPayment { get; set; }
       
        public DateTime PaymentReceiveDate { get; set; }
    }
}
