﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using DebtCollectionBLL.DTOs;
using DebtCollectionDAL.Models;

namespace DebtCollectionBLL.Mapper
{
    public class Auto_Mapper:Profile
    {
        public Auto_Mapper()
        {
            CreateMap<PaymentTrack, PaymentTrackDTO>()
                .ForMember(cd => cd.PaymentTrackId, opt => opt.MapFrom(cld => cld.PaymentTrackId))
                .ForMember(cd => cd.LoanAppId, opt => opt.MapFrom(cld => cld.LoanAppId))
                .ForMember(cd => cd.MonthNo, opt => opt.MapFrom(cld => cld.MonthNo))
                .ForMember(cd => cd.Status, opt => opt.MapFrom(cld => cld.Status))
                .ForMember(cd => cd.DueDateOfPayment, opt => opt.MapFrom(cld => cld.DueDateOfPayment))
                .ForMember(cd => cd.PaymentReceiveDate, opt => opt.MapFrom(cld => cld.PaymentReceiveDate));
        }
    }
}
