
using DebtCollectionBLL.Mapper;
using DebtCollectionBLL.Services;
using DebtCollectionDAL;
using DebtCollectionDAL.Repository;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<DebtCollectionContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("DebtCollectionConnection"));
});
builder.Services.AddScoped<DbContext,DebtCollectionContext>(); 
builder.Services.AddScoped<IPaymentTrackService ,PaymentTrackService>();
builder.Services.AddScoped<IPaymentTrackRepository,PaymentTrackRepository>();
builder.Services.AddAutoMapper(typeof(Auto_Mapper));
var app = builder.Build();

// Configure the HTTP request pipeline. //below r middlewares  //activation part
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseCors(options =>
{

    options.AllowAnyHeader();
    options.AllowAnyOrigin();
    options.AllowAnyMethod();



});




app.UseAuthorization();

app.MapControllers();

app.Run();
