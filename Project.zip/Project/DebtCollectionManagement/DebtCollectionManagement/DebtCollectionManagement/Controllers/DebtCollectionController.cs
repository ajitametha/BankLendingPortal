﻿using DebtCollectionBLL.DTOs;
using DebtCollectionBLL.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DebtCollectionManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DebtCollectionController : ControllerBase
    {
        private readonly IPaymentTrackService _payment;
        public DebtCollectionController(IPaymentTrackService payment)
        {
            _payment = payment;
        }


        [HttpPost("create")]
        public IActionResult addbanker([FromBody] PaymentTrackDTO model)
        {
            
            _payment.AddPaymentTrack(model);
            return Ok();
        }


        [HttpPut("update/{PaymentTrackid}")]
        public IActionResult Updatestatus([FromBody]UpdateTrackDTO model,string PaymentTrackid) 
        {
            _payment.UpdatePaymentStatus(model, PaymentTrackid);
            return Ok();
        }


        [HttpGet("GetListofdefaultyerbydate")]
        public IActionResult GetListby15()
        {
            var temp = _payment.GetDefaultersbydate15();
            return Ok(temp);
        }


        [HttpGet("GetListofdefaulter")]
        public IActionResult GetListdefaulter()
        {
            var temp = _payment.GetDefaulterstrackforpayment();
            return Ok(temp);
        }


        [HttpGet("GetList")]
        public IActionResult GetListd()
        {
            var temp = _payment.GetListOfRecord();
            return Ok(temp);
        }
    }
}
