import { ViewChild } from '@angular/core';
import { Component } from '@angular/core';
import { loanDetails } from '../../models/loanDetails.model';
import { ServiceclassService } from '../../services/serviceclass.service';
import  { NgForm } from '@angular/forms';
import { Subscription } from 'rxjs'; //whenever we need to access any api, we need to subscribe to it.
// and later unsubscribe (Automatically)
@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrl: './report.component.css'
})
export class ReportComponent {

  @ViewChild('f') form:NgForm;

  model: loanDetails[];

  constructor (private service: ServiceclassService){

  }

  onSubmit(){
    this.service.getAllLoans()
    .subscribe({ //for usin the apii v hve 2 subscribe
      next: (response) => {
        this.model = response; // this will add response to the model variable. Which is used to display
        // in html, using *ngFor
        console.log(this.model);
      }
    });
  }
 
}
