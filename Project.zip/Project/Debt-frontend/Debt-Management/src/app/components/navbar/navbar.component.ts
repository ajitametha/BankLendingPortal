import { Component } from '@angular/core';

@Component({
  selector: 'app-navbar', // whenever v wr this it will access d templateurl and styleURL 
  templateUrl: './navbar.component.html', //this one has the location of html file
  styleUrl: './navbar.component.css' //locn of css file
})
export class NavbarComponent {

  //by writing export class it work likee public it can be accesses from anywhere in my project
}
