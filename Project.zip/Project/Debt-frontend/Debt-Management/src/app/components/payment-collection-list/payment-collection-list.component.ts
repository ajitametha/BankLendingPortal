import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ServiceclassService } from '../../services/serviceclass.service';
import { loanDetails } from '../../models/loanDetails.model';



@Component({ //decorator
  selector: 'app-payment-collection-list', //helps in using this componant
  templateUrl: './payment-collection-list.component.html',
  styleUrl: './payment-collection-list.component.css'
})
export class PaymentCollectionListComponent {

  constructor (private service: ServiceclassService){  //declared object

  }
  loans: loanDetails;

  getCurrentDate(): string {
    const today: Date = new Date();
    const year: number = today.getFullYear();
    const month: string = (today.getMonth() + 1).toString().padStart(2, '0');
    const day: string = today.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
  }


  onSubmit(form: NgForm) {

    // loans:loanDetails;
    if (form.valid) {
      this.loans = form.value;
      
      }
      


      this.service.submitReport(this.loans).subscribe(response => { //values r getting pushed to api using
        // service class function
        alert('Report submitted successfully');
      })
    }
  }

