import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentCollectionListComponent } from './payment-collection-list.component';

describe('PaymentCollectionListComponent', () => {
  let component: PaymentCollectionListComponent;
  let fixture: ComponentFixture<PaymentCollectionListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PaymentCollectionListComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PaymentCollectionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
