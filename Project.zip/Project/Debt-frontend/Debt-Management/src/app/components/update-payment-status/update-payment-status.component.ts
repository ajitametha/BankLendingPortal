import { Component, OnInit, Input } from '@angular/core';
import { Subscription } from 'rxjs';
import { loanDetails } from '../../models/loanDetails.model';
//import { updateLoans } from '../../models/updateLoans.model';
import { ServiceclassService } from '../../services/serviceclass.service';
//import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-update-payment-status',
  templateUrl: './update-payment-status.component.html',
  styleUrl: './update-payment-status.component.css'
})
export class UpdatePaymentStatusComponent implements OnInit{
 
  // before submitting the form ngOnIt function will run
  
private UpdatePaymentSubscription?: Subscription;
model: loanDetails[];

constructor (private service: ServiceclassService){

}
@Input() status:string="";
@Input() paymentTrackId:string="";
  ngOnInit(): void {    
    this.UpdatePaymentSubscription = this.service.getAllLoans()
    .subscribe({
      next: (response) => {
        this.model = response; //after model gets data values d ngfor in html will run
        console.log(this.model);
      }
    });
  }
  onFormSubmit(formData: any) //getting data here
  {
    //console.log(formData.status);
    //console.log(formData.paymentTrackId);

    this.service.updateStatusValue(formData.paymentTrackId, formData.status).subscribe({
      next: (response) => {
        console.log("Updation Successful !!");
      }
    })
  }
}
