import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { loanDetails } from '../models/loanDetails.model';
import { updateLoans } from '../models/updateLoans.model';

@Injectable({
  providedIn: 'root'
})
export class ServiceclassService {

  constructor(private http:HttpClient) { }

  submitReport(loans:loanDetails): Observable<any> {
    return this.http.post(`https://localhost:7135/api/DebtCollection/create`, loans);
  }

  getAllLoans(): Observable<loanDetails[]>{
    return this.http.get<loanDetails[]>('https://localhost:7135/api/DebtCollection/GetList');
  }
  // createLoans(loans:loanDetails){
  //   return this.http.post<loanDetails[]>('https://localhost:7135/api/DebtCollection/create',loans);
  // }
  getReport(): Observable<loanDetails[]>{
    return this.http.get<loanDetails[]>('https://localhost:7135/api/DebtCollection/GetListofdefaulter');
  }
  updateStatusValue(PaymentTrackid: string, status: string){
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    })
    const body = { "status": status };
    return this.http.put<string>("https://localhost:7135/api/DebtCollection/update/" + PaymentTrackid, body, {headers});
  }
}

