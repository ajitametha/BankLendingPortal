import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UpdatePaymentStatusComponent } from './components/update-payment-status/update-payment-status.component';
import { PaymentCollectionListComponent } from './components/payment-collection-list/payment-collection-list.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { HomeComponent } from './home/home/home.component';
import { ReportComponent } from './components/report/report.component';

@NgModule({
  declarations: [
    AppComponent,
    UpdatePaymentStatusComponent,
    PaymentCollectionListComponent,
    
    NavbarComponent,
    HomeComponent,
    ReportComponent
  ],
  imports: [
    BrowserModule, //loading on browser
    AppRoutingModule, //for url routing
    FormsModule,
    HttpClientModule

  ],
  providers: [],
  bootstrap: [AppComponent] //array of bootstrap
})
export class AppModule { }
