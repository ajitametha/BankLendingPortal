export interface updateLoans{
    paymentTrackId?: string;  
    status? : string; 
   
    


}
