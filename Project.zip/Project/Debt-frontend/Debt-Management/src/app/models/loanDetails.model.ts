export interface loanDetails{
     paymentTrackId?: string; 
     loanAppId? : string;
    
     monthNo? : Number;
   
     status? : string; 
    
     dueDateOfPayment?: Date; 
   
     paymentReceiveDate? : Date; 


}