import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PaymentCollectionListComponent } from './components/payment-collection-list/payment-collection-list.component';
import { ReportComponent } from './components/report/report.component';
import { UpdatePaymentStatusComponent } from './components/update-payment-status/update-payment-status.component';
import { HomeComponent } from './home/home/home.component';

const routes: Routes = [
  {
    path: 'updatestatus',
    component: UpdatePaymentStatusComponent
  },
  {
    path:'report',
    component:ReportComponent
 },
 {
  path: 'add-payment-collection',
  component:PaymentCollectionListComponent
 },
 {
  path: 'home',
  component:HomeComponent
 }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
